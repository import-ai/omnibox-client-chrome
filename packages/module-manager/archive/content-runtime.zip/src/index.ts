import { mount } from '@src/Root';

mount();
console.log('runtime script loaded');
